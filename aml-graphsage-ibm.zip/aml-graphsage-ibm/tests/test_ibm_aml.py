"""Unit tests for the IBM AML loader and account-graph builder."""
import numpy as np

import ibm_aml
import make_sample


def _sample_csv(tmp_path, accounts=300, rings=10):
    df = make_sample.generate(n_accounts=accounts, laundering_rings=rings, seed=7)
    p = tmp_path / "trans.csv"
    df.to_csv(p, index=False)
    return str(p)


def test_sample_has_ibm_schema(tmp_path):
    path = _sample_csv(tmp_path)
    import pandas as pd
    cols = list(pd.read_csv(path, nrows=1).columns)
    assert cols == ibm_aml.RAW_COLS


def test_load_transactions_canonical(tmp_path):
    edges = ibm_aml.load_transactions(_sample_csv(tmp_path))
    for c in ["src", "dst", "amount", "timestamp", "pay_format", "is_laundering"]:
        assert c in edges.columns
    assert (edges["src"] != edges["dst"]).all()          # no self-loops
    assert set(edges["is_laundering"].unique()) <= {0, 1}


def test_build_account_graph_shapes(tmp_path):
    edges = ibm_aml.load_transactions(_sample_csv(tmp_path))
    g = ibm_aml.build_account_graph(edges)
    N = len(g["node_ids"])
    assert g["features"].shape[0] == N
    assert g["features"].shape[1] == len(g["feat_names"])
    assert g["labels"].shape[0] == N
    assert set(np.unique(g["labels"])) <= {0, 1}
    # edge indices are valid node positions
    assert g["edge_index"].min() >= 0
    assert g["edge_index"].max() < N
    # some accounts must be labelled laundering (sample injects typologies)
    assert g["labels"].sum() > 0


def test_bad_input_rejected(tmp_path):
    import pandas as pd
    bad = tmp_path / "bad.csv"
    pd.DataFrame({"a": [1], "b": [2]}).to_csv(bad, index=False)
    try:
        ibm_aml.load_transactions(str(bad))
        assert False, "should have raised on non-IBM schema"
    except ValueError:
        pass
