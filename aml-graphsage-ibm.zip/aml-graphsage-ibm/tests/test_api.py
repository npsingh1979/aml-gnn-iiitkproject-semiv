"""API tests against a freshly scored report."""
import os
import subprocess
import sys

from fastapi.testclient import TestClient

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _ensure_report():
    """Train once into the repo's default outputs/ so serve.py can read it."""
    out = os.path.join(ROOT, "outputs")
    rep = os.path.join(out, "account_risk_report.csv")
    if os.path.exists(rep):
        return
    import make_sample
    csv = os.path.join(ROOT, "data", "sample_HI-Small_Trans.csv")
    if not os.path.exists(csv):
        make_sample.generate(n_accounts=800, laundering_rings=20).to_csv(csv, index=False)
    subprocess.run([sys.executable, os.path.join(ROOT, "src", "train_graphsage.py"),
                    "--input", csv, "--epochs", "5"], check=True)


def test_health_and_report_endpoints():
    _ensure_report()
    from src.serve import app
    c = TestClient(app)

    assert c.get("/health").json()["status"] == "healthy"

    s = c.get("/stats").json()
    assert s["accounts"] > 0

    top = c.get("/accounts/top?n=5").json()
    assert len(top) == 5
    assert top[0]["risk_score"] >= top[-1]["risk_score"]  # sorted desc

    acc = top[0]["account"]
    one = c.get(f"/accounts/{acc}").json()
    assert one["account"] == acc

    assert c.get("/accounts/__does_not_exist__").status_code == 404
