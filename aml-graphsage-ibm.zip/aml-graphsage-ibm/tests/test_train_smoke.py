"""End-to-end smoke test: train 3 epochs on a tiny sample, check artifacts."""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_training_produces_artifacts(tmp_path):
    import make_sample
    csv = tmp_path / "trans.csv"
    make_sample.generate(n_accounts=400, laundering_rings=12, seed=11).to_csv(csv, index=False)

    out = tmp_path / "outputs"
    mdl = tmp_path / "models"
    cmd = [sys.executable, os.path.join(ROOT, "src", "train_graphsage.py"),
           "--input", str(csv), "--epochs", "3",
           "--outdir", str(out), "--modeldir", str(mdl)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr[-2000:]

    assert (mdl / "graphsage_aml.pt").exists()
    assert (out / "account_risk_report.csv").exists()
    metrics = json.load(open(out / "metrics.json"))
    assert "test" in metrics and "recall" in metrics["test"]
    assert metrics["nodes"] > 0 and metrics["edges"] > 0
