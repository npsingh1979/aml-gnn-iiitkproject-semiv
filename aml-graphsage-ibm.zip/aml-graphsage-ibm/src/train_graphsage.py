"""
train_graphsage.py — GraphSAGE node classification for AML mule detection on the
IBM Transactions-for-AML dataset.

Pipeline:
  raw IBM AML *_Trans.csv
     -> ibm_aml.load_transactions   (canonical edge table)
     -> ibm_aml.build_account_graph (nodes, labels, features, edge_index)
     -> StandardScaler on node features
     -> 2-layer GraphSAGE (PyTorch Geometric), class-weighted, mini-batched
     -> metrics (PR-AUC, ROC-AUC, recall/precision) + per-account risk report

Runs on CPU. Mini-batched with NeighborLoader so it scales from the 4k-account
sample up to the real HI-Small file (~500k accounts, ~5M edges).

Usage:
    python src/train_graphsage.py --input data/sample_HI-Small_Trans.csv
    python src/train_graphsage.py --input /path/to/HI-Small_Trans.csv --epochs 30
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import (average_precision_score, roc_auc_score,
                             precision_recall_fscore_support, confusion_matrix)
from sklearn.preprocessing import StandardScaler
from torch_geometric.data import Data
from torch_geometric.nn import SAGEConv

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ibm_aml  # noqa: E402


class GraphSAGE(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels=64, out_channels=2, dropout=0.3):
        super().__init__()
        self.conv1 = SAGEConv(in_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, hidden_channels)
        self.lin = torch.nn.Linear(hidden_channels, out_channels)
        self.dropout = dropout

    def forward(self, x, edge_index):
        x = F.relu(self.conv1(x, edge_index))
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = F.relu(self.conv2(x, edge_index))
        x = F.dropout(x, p=self.dropout, training=self.training)
        return self.lin(x)


def make_masks(labels, seed=42, val=0.15, test=0.15):
    """Stratified train/val/test node masks."""
    rng = np.random.default_rng(seed)
    N = len(labels)
    train = np.zeros(N, bool); va = np.zeros(N, bool); te = np.zeros(N, bool)
    for cls in (0, 1):
        idx = np.where(labels == cls)[0]
        rng.shuffle(idx)
        n_te = int(len(idx) * test); n_va = int(len(idx) * val)
        te[idx[:n_te]] = True
        va[idx[n_te:n_te + n_va]] = True
        train[idx[n_te + n_va:]] = True
    return train, va, te


def build_data(input_path, nrows=None):
    edges = ibm_aml.load_transactions(input_path, nrows=nrows)
    g = ibm_aml.build_account_graph(edges)

    X = StandardScaler().fit_transform(g["features"])
    ei = g["edge_index"]
    # undirected message passing: add reverse edges
    ei_bi = np.hstack([ei, ei[[1, 0]]])

    data = Data(
        x=torch.tensor(X, dtype=torch.float),
        edge_index=torch.tensor(ei_bi, dtype=torch.long),
        y=torch.tensor(g["labels"], dtype=torch.long),
    )
    tr, va, te = make_masks(g["labels"])
    data.train_mask = torch.tensor(tr); data.val_mask = torch.tensor(va); data.test_mask = torch.tensor(te)
    return data, g, edges


@torch.no_grad()
def full_scores(model, data):
    model.eval()
    logits = model(data.x, data.edge_index)
    return F.softmax(logits, dim=1)[:, 1].cpu().numpy()


def evaluate(scores, y, mask, thr=0.5):
    yv = y[mask]; sv = scores[mask]
    out = {"n": int(mask.sum()), "positives": int(yv.sum())}
    if yv.sum() > 0 and yv.sum() < len(yv):
        out["pr_auc"] = float(average_precision_score(yv, sv))
        out["roc_auc"] = float(roc_auc_score(yv, sv))
    pred = (sv >= thr).astype(int)
    p, r, f1, _ = precision_recall_fscore_support(yv, pred, average="binary", zero_division=0)
    out.update({"precision": float(p), "recall": float(r), "f1": float(f1)})
    tn, fp, fn, tp = confusion_matrix(yv, pred, labels=[0, 1]).ravel()
    out["confusion"] = {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="IBM AML *_Trans.csv (or the sample)")
    ap.add_argument("--nrows", type=int, default=None, help="cap rows (for huge files)")
    ap.add_argument("--epochs", type=int, default=25)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--lr", type=float, default=0.01)
    ap.add_argument("--batch", type=int, default=2048)
    ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--outdir", default="outputs")
    ap.add_argument("--modeldir", default="models")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True); os.makedirs(args.modeldir, exist_ok=True)
    torch.manual_seed(42)

    print(f"[1/4] loading + building graph from {args.input} ...")
    data, g, edges = build_data(args.input, nrows=args.nrows)
    N, Fdim = data.x.shape
    pos = int(data.y.sum())
    print(f"      accounts(nodes)={N:,}  edges={data.edge_index.shape[1]:,}  "
          f"features={Fdim}  laundering_accounts={pos:,} ({pos/N*100:.2f}%)")

    model = GraphSAGE(Fdim, hidden_channels=args.hidden)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=5e-4)
    # class weights (laundering rare)
    w = torch.tensor([1.0, max(1.0, (N - pos) / max(pos, 1))], dtype=torch.float)
    print(f"      class weight for laundering class = {w[1]:.1f}")

    # NOTE: full-batch training (whole graph each step) — works out of the box.
    # For the very large HI-Large/LI-Large files, install `torch-sparse pyg-lib`
    # and replace this loop with a torch_geometric.loader.NeighborLoader over
    # data.train_mask (num_neighbors=[15,10]); the model.forward is unchanged.
    print(f"[2/4] training GraphSAGE for {args.epochs} epochs (CPU, full-batch) ...")
    tm = data.train_mask
    for epoch in range(1, args.epochs + 1):
        model.train()
        opt.zero_grad()
        out = model(data.x, data.edge_index)
        loss = F.cross_entropy(out[tm], data.y[tm], weight=w)
        loss.backward(); opt.step()
        if epoch % 5 == 0 or epoch == 1:
            sc = full_scores(model, data)
            val = evaluate(sc, data.y.numpy(), data.val_mask.numpy(), args.threshold)
            print(f"      epoch {epoch:>3}  loss={float(loss):.4f}  "
                  f"val_pr_auc={val.get('pr_auc',float('nan')):.4f}  val_recall={val['recall']:.3f}")

    print("[3/4] evaluating on held-out test accounts ...")
    scores = full_scores(model, data)
    y = data.y.numpy()
    report = {
        "dataset": os.path.basename(args.input),
        "nodes": N, "edges": int(data.edge_index.shape[1]), "features": Fdim,
        "laundering_accounts": pos, "threshold": args.threshold,
        "val": evaluate(scores, y, data.val_mask.numpy(), args.threshold),
        "test": evaluate(scores, y, data.test_mask.numpy(), args.threshold),
    }
    print(json.dumps(report["test"], indent=2))

    # ---- persist model + metrics + per-account risk report ----------------
    torch.save(model.state_dict(), os.path.join(args.modeldir, "graphsage_aml.pt"))
    with open(os.path.join(args.outdir, "metrics.json"), "w") as fh:
        json.dump(report, fh, indent=2)

    risk = pd.DataFrame({
        "account": g["node_ids"],
        "risk_score": scores.round(4),
        "label": y,
        "flagged": (scores >= args.threshold).astype(int),
    }).sort_values("risk_score", ascending=False)
    risk.to_csv(os.path.join(args.outdir, "account_risk_report.csv"), index=False)

    print(f"[4/4] saved: {args.modeldir}/graphsage_aml.pt, "
          f"{args.outdir}/metrics.json, {args.outdir}/account_risk_report.csv")
    print("      top 5 highest-risk accounts:")
    print(risk.head(5).to_string(index=False))


if __name__ == "__main__":
    main()
