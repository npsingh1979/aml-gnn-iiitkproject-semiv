# Architecture

```
 IBM AML *_Trans.csv  (one row = one transaction: Account -> Account.1)
        │
        ▼
 ibm_aml.load_transactions   ──►  canonical edge table
        │                         src, dst, amount, timestamp, pay_format,
        │                         currency, is_laundering
        ▼
 ibm_aml.build_account_graph ──►  nodes (accounts), directed edge_index,
        │                         account-level labels, 19 graph features
        ▼
 StandardScaler  ──►  add reverse edges (undirected message passing)
        │
        ▼
 GraphSAGE (2× SAGEConv + linear)   class-weighted cross-entropy, full-batch
        │
        ├──►  metrics.json            PR-AUC / ROC-AUC / recall / confusion
        ├──►  account_risk_report.csv ranked per-account risk scores
        └──►  graphsage_aml.pt        trained weights
                     │
                     ▼
            serve.py (FastAPI)  ──►  /accounts/top, /accounts/{id}, /score
```

## Design decisions

**Node = account, edge = transaction.** The IBM dataset gives real counterparties,
so the graph is the money-flow network itself — the only structure on which a GNN
can actually do message passing. An account's label is "involved in any laundering
transaction," the standard node-level label for this dataset.

**Features are graph-derived, not raw columns.** Fan-in / fan-out ratios, net-flow
and pass-through ratios, cash-out mix and temporal burst are exactly the typology
signatures of collector, forwarder and cash-out mules. GraphSAGE then combines a
node's own features with its neighbourhood.

**Full-batch training** keeps the dependency surface small (no `torch-sparse` /
`pyg-lib` native build). For HI-Large / LI-Large, switch to `NeighborLoader`
mini-batching — the model code is unchanged.

**Class weighting** handles the heavy imbalance (laundering accounts are a small
minority); evaluation leads with PR-AUC and recall rather than accuracy.

## Mapping to a bank deployment

Replace the Kaggle file with de-identified EDW transactions mapped to the
canonical edge schema. Entity resolution (one customer → one node) and typology
labels from the existing AML/EDD feedback loop improve both the graph and the
labels. The FastAPI service is the integration point for an investigator UI or a
case-management queue.
