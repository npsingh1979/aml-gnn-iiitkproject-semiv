"""
serve.py — FastAPI service exposing the GraphSAGE AML results to investigators.

Endpoints:
  GET  /health                     service + model/report status
  GET  /stats                      graph size, flagged count, true mules
  GET  /accounts/top?n=20          highest-risk accounts
  GET  /accounts/{account_id}      risk for one account
  POST /score   {"input": "path/to/HI-Small_Trans.csv", "n": 50}
                                   live GraphSAGE scoring of a transactions file

Run:
    uvicorn src.serve:app --reload --port 8000
    open http://localhost:8000/docs
"""
from __future__ import annotations

import os
from functools import lru_cache

import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# import loader/graph builder whether run as package (src.serve) or flat
try:
    from . import ibm_aml
except ImportError:  # pragma: no cover
    import ibm_aml  # type: ignore

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPORT = os.path.join(ROOT, "outputs", "account_risk_report.csv")
MODEL = os.path.join(ROOT, "models", "graphsage_aml.pt")

app = FastAPI(
    title="AML GraphSAGE — IBM Transactions for Anti-Money Laundering",
    description="GraphSAGE mule/AML risk scoring over an account transaction graph.",
    version="1.0.0",
)


@lru_cache(maxsize=1)
def _report() -> pd.DataFrame:
    if not os.path.exists(REPORT):
        raise HTTPException(503, f"No risk report yet. Train first: "
                                 f"python src/train_graphsage.py --input <file>")
    return pd.read_csv(REPORT)


class ScoreRequest(BaseModel):
    input: str                 # server-side path to an IBM AML *_Trans.csv
    n: int = 50
    nrows: int | None = None
    threshold: float = 0.5


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "report_present": os.path.exists(REPORT),
        "model_present": os.path.exists(MODEL),
    }


@app.get("/stats")
def stats():
    df = _report()
    return {
        "accounts": int(len(df)),
        "flagged": int(df["flagged"].sum()),
        "true_mules_labelled": int(df["label"].sum()) if "label" in df else None,
        "mean_risk": round(float(df["risk_score"].mean()), 4),
    }


@app.get("/accounts/top")
def top(n: int = 20):
    df = _report().sort_values("risk_score", ascending=False).head(max(1, n))
    return df.to_dict(orient="records")


@app.get("/accounts/{account_id}")
def account(account_id: str):
    df = _report()
    row = df[df["account"] == account_id]
    if row.empty:
        raise HTTPException(404, f"account '{account_id}' not found in risk report")
    return row.iloc[0].to_dict()


@app.post("/score")
def score(req: ScoreRequest):
    """Live GraphSAGE scoring of a transactions file using the trained model."""
    if not os.path.exists(req.input):
        raise HTTPException(400, f"input file not found on server: {req.input}")
    if not os.path.exists(MODEL):
        raise HTTPException(503, "no trained model; run training first")

    import torch
    from sklearn.preprocessing import StandardScaler
    from torch_geometric.data import Data
    # import the model class from the trainer module
    try:
        from .train_graphsage import GraphSAGE
    except ImportError:  # pragma: no cover
        from train_graphsage import GraphSAGE  # type: ignore

    edges = ibm_aml.load_transactions(req.input, nrows=req.nrows)
    g = ibm_aml.build_account_graph(edges)
    X = StandardScaler().fit_transform(g["features"])
    import numpy as np
    ei = g["edge_index"]
    ei_bi = np.hstack([ei, ei[[1, 0]]])
    data = Data(x=torch.tensor(X, dtype=torch.float),
                edge_index=torch.tensor(ei_bi, dtype=torch.long))

    model = GraphSAGE(X.shape[1])
    model.load_state_dict(torch.load(MODEL, map_location="cpu"))
    model.eval()
    with torch.no_grad():
        probs = torch.softmax(model(data.x, data.edge_index), dim=1)[:, 1].numpy()

    out = pd.DataFrame({"account": g["node_ids"], "risk_score": probs.round(4),
                        "flagged": (probs >= req.threshold).astype(int)})
    out = out.sort_values("risk_score", ascending=False).head(max(1, req.n))
    return {"accounts_scored": int(len(g["node_ids"])),
            "flagged": int((probs >= req.threshold).sum()),
            "top": out.to_dict(orient="records")}
