# Detection of Money-Mule Accounts using Graph Neural Networks (GraphSAGE) on the IBM Anti-Money-Laundering Transaction Dataset

**A Project Report**

Submitted by: **Nripendra Pratap Singh**
Domain: Financial Crime Analytics / Machine Learning
Dataset: IBM Transactions for Anti-Money Laundering (AML), Kaggle
Technique: GraphSAGE (Graph Neural Network, PyTorch Geometric)

---

## Abstract

Money laundering through "mule" bank accounts is one of the hardest problems in
financial-crime detection because a mule account, viewed on its own, usually
looks ordinary. What exposes it is its *behaviour inside the transaction
network* — money passing straight through, many accounts funnelling into one,
or funds cycling around a ring. Traditional rule-based Anti-Money-Laundering
(AML) systems and tabular machine-learning models score each account in
isolation and therefore both miss coordinated rings and raise large numbers of
false positives.

This project builds a **Graph Neural Network (GNN)** based mule-detection system
that treats the data as the money-flow graph it actually is. Using the publicly
available **IBM Transactions for Anti-Money Laundering (AML)** dataset — in which
every record is a transaction from one account to another, with amount,
timestamp and a laundering label — we construct an account-level transaction
graph and train a **GraphSAGE** model to classify each account as mule /
non-mule. The system is delivered as a reproducible, tested, and deployable code
base with a REST API for investigators. On a schema-identical verification
sample the model achieves a **ROC-AUC of 0.90 at 0.80 recall**, and ranks true
mule accounts at the very top of its risk list, demonstrating that network
position is a strong, learnable signal for mule detection.

---

## 1. Introduction

Banks are legally required, under RBI directions and global FATF standards, to
detect and report suspicious transactions. A large and growing share of fraud
proceeds is moved through **money mules** — accounts (sometimes rented, tricked,
or purpose-opened) that receive illicit funds and quickly pass them on, breaking
the trail between the victim and the criminal.

Conventional AML transaction-monitoring systems rely on hand-written rules
(e.g. "flag cash deposits over a threshold"). These rules are transparent but
rigid: they fire on many legitimate customers (false positives) while missing
laundering patterns that are only visible when several accounts are considered
*together*. Supervised tabular machine-learning improves ranking but still
treats each account as an independent row of features.

The key insight of this project is that **mule behaviour is relational**. A
Graph Neural Network can learn directly from the structure of money movement,
aggregating information from an account's neighbours (who it pays and who pays
it) to decide how mule-like it is. We implement this using **GraphSAGE**, a
widely used inductive GNN, on a realistic, labelled AML dataset.

---

## 2. Problem Statement and Objectives

**Problem statement.** Given a set of inter-account transactions, automatically
identify and rank the accounts that are acting as money mules / laundering
accounts, so that investigators can prioritise the highest-risk accounts and so
that coordinated laundering structures (fan-in, fan-out, pass-through chains,
cycles) are detected that per-account methods miss.

**Objectives.**
1. Model the transaction data as an account-level directed graph.
2. Engineer graph-based features that capture mule typologies.
3. Train a GraphSAGE GNN to classify accounts as mule / non-mule.
4. Evaluate with metrics appropriate to a rare-event problem (PR-AUC, ROC-AUC,
   recall), not plain accuracy.
5. Produce a per-account risk report and expose it through a REST API suitable
   for integration into an investigation workflow.
6. Make the whole system reproducible (tests, CI, containerisation) so it runs
   on GitHub out of the box.

---

## 3. Background and Related Work

**Anti-money-laundering (AML) monitoring.** Classical systems are rule-based and
produce alerts for human review. Industry false-positive rates are very high
(often quoted above 90%), which motivates data-driven methods.

**Tabular machine learning for fraud.** Gradient-boosted trees (XGBoost,
LightGBM, CatBoost) are strong baselines on per-account or per-transaction
feature tables. They do not, however, use the relationships between accounts.

**Graph methods and GNNs.** Where transaction *edges* exist, the data forms a
graph and Graph Neural Networks can learn node representations by message
passing. **GraphSAGE** (Hamilton, Ying & Leskovec, 2017) is an inductive variant
that learns aggregator functions over a node's sampled neighbourhood, making it
suitable for large and evolving graphs. GNNs have been applied to financial
crime in the literature (e.g. the Elliptic Bitcoin dataset for illicit-node
detection).

**A note on data shape.** A GNN is only applicable when the dataset actually
contains counterparty links. Many popular fraud datasets (credit-card, tabular
account summaries) have no account-to-account edges and therefore cannot support
a true GNN — tabular ML is the ceiling for those. The IBM AML dataset used here
*does* contain the edges, which is precisely why a GNN approach is valid.

---

## 4. Dataset

**Source.** IBM "Transactions for Anti-Money Laundering (AML)", released by
IBM Research on Kaggle
(`kaggle.com/datasets/ealtman2019/ibm-transactions-for-anti-money-laundering-aml`).
It is a large, realistic, synthetically-generated set of financial transactions
with laundering labels and embedded laundering typologies, created so that AML
models can be developed and benchmarked without using real customer data.

**Schema.** Each row is one transaction with the fields:

| Field | Meaning |
|---|---|
| Timestamp | date/time of the transaction |
| From Bank, Account | sending bank and account id |
| To Bank, Account.1 | receiving bank and account id |
| Amount Paid / Received | value and currency on each side |
| Payment Format | ACH, Cheque, Wire, Credit Card, Cash, Bitcoin, Reinvestment |
| Is Laundering | 1 if the transaction is part of laundering, else 0 |

The suite ships several sizes (HI-Small, HI-Medium, HI-Large, and LI-* variants
with different laundering ratios); **HI-Small** is used as the primary file.

**Verification sample.** Because the Kaggle file must be downloaded with an
account, this project also includes a generator (`make_sample.py`) that produces
a **schema-identical** synthetic file embedding the same laundering typologies
(fan-in collector, fan-out distributor, pass-through chain, cycle). It is read
through the *same loader* as the real file, so the pipeline can be demonstrated
and tested end-to-end without any download. All results reported in Section 8
are on this verification sample unless stated otherwise.

---

## 5. System Design and Methodology

### 5.1 Graph construction

- **Nodes** = accounts, keyed as `<Bank>_<Account>` so that identical account
  numbers at different banks remain distinct.
- **Edges** = transactions, directed from sender to receiver, carrying amount,
  timestamp and payment format.
- **Node label** = 1 if the account participates in *any* transaction flagged
  `Is Laundering = 1` (the standard account-level label for this dataset).

For message passing, reverse edges are added so that a receiving account can
also aggregate information from the accounts that pay it (undirected
propagation).

### 5.2 Feature engineering

Nineteen features are derived purely from the graph, chosen to express the
typology signatures of mules:

| Group | Features |
|---|---|
| Degree | out-degree, in-degree, total degree |
| Counterparties | unique out / in counterparties, fan-in ratio, fan-out ratio |
| Amounts | sum / mean / max sent and received, received-to-sent ratio |
| Mule signal | net-flow ratio, pass-through ratio (money in ≈ money out) |
| Cash-out | ratio of Cash/Bitcoin outgoing payments |
| Temporal | maximum transactions in a single day, number of active days |

Features are standardised (zero mean, unit variance) before training.

### 5.3 Model architecture

A two-layer **GraphSAGE** network implemented in PyTorch Geometric:

```
Input features (19) 
   → SAGEConv → ReLU → Dropout 
   → SAGEConv → ReLU → Dropout 
   → Linear → 2-class output (mule / non-mule)
```

Because mule accounts are a small minority, the cross-entropy loss is
**class-weighted** (weight on the mule class ≈ non-mule/mule ratio), which
prevents the model from trivially predicting "everyone is clean".

### 5.4 Training and evaluation protocol

- Stratified train / validation / test split of nodes (70 / 15 / 15).
- Full-batch training on CPU (the code notes how to switch to `NeighborLoader`
  mini-batching for the very large files).
- Evaluation metrics suited to rare events: **PR-AUC, ROC-AUC, precision,
  recall, F1, and the confusion matrix**. Accuracy is deliberately not used as a
  headline because it is misleading at low positive rates.

---

## 6. Implementation

**Technology stack.** Python 3.11, PyTorch 2.x, PyTorch Geometric,
scikit-learn, pandas, NumPy, FastAPI + Uvicorn.

**Module layout.**

| File | Responsibility |
|---|---|
| `src/ibm_aml.py` | load IBM file → canonical edges → account graph, labels, features |
| `src/make_sample.py` | generate the schema-exact verification sample |
| `src/train_graphsage.py` | build graph, train GraphSAGE, evaluate, write risk report |
| `src/serve.py` | FastAPI service: top-risk, per-account lookup, live `/score` |
| `tests/` | loader, end-to-end training, and API tests |
| `.github/workflows/ci.yml` | install, test, smoke-train on every push |
| `Dockerfile`, `Makefile`, `.devcontainer/` | container, shortcuts, Codespaces |

**Outputs produced per run.**
- `outputs/metrics.json` — all evaluation metrics (validation + test)
- `outputs/account_risk_report.csv` — every account ranked by risk score
- `models/graphsage_aml.pt` — trained model weights

---

## 7. Experimental Setup

The verification run was executed on the generated sample:

| Property | Value |
|---|---|
| Accounts (nodes) | 3,998 |
| Transactions (edges) | 32,744 |
| Features per account | 19 |
| Laundering accounts | 405 (10.1%) |
| Epochs | 40 |
| Optimiser | Adam (lr 0.01, weight decay 5e-4) |
| Hardware | CPU |

---

## 8. Results and Discussion

### 8.1 Quantitative results (held-out test accounts)

| Metric | Validation | Test |
|---|---|---|
| ROC-AUC | 0.901 | **0.898** |
| PR-AUC | 0.600 | 0.610 |
| Precision | 0.433 | 0.440 |
| Recall | 0.750 | **0.800** |
| F1 | 0.549 | 0.568 |

Test confusion matrix (threshold 0.5), 598 accounts, 60 true mules:

|  | Predicted clean | Predicted mule |
|---|---|---|
| **Actual clean** | 477 (TN) | 61 (FP) |
| **Actual mule** | 12 (FN) | 48 (TP) |

### 8.2 Discussion

The model recovers **80% of true mule accounts** and attains a **ROC-AUC of
0.90**, confirming that an account's position in the money-flow graph is a strong
predictor of mule behaviour. The highest-risk accounts output by the model are
all genuine mules, which is exactly the behaviour an investigation team needs:
a reliable ordering so that scarce analyst time is spent on the most suspicious
accounts first.

Precision at the default 0.5 threshold is moderate (0.44), i.e. some clean
accounts are flagged. In practice the operating threshold is tuned to the
investigation team's capacity, trading precision against recall; the system
outputs a continuous risk score so this threshold can be set at deployment.

**Honesty note on the figures.** The numbers above are from the synthetic
verification sample, whose laundering edges are attached partly to random
counterparties and therefore give a *noisier* (harder, more pessimistic)
signal than the real IBM data, where laundering transactions form cleaner,
structured typologies with much larger neighbourhoods. On the real HI-Small
file the same pipeline is expected to separate mules more strongly; those
figures should be generated by running the provided command on the downloaded
dataset and are not claimed here, as they were not measured in this run.

---

## 9. Deployment

The trained model is served through a FastAPI application, turning the model
from a notebook artefact into an integration point for an investigation system:

| Endpoint | Purpose |
|---|---|
| `GET /health` | service and model status |
| `GET /stats` | graph size, number flagged, labelled mules |
| `GET /accounts/top?n=20` | highest-risk accounts |
| `GET /accounts/{id}` | risk for a single account |
| `POST /score` | live GraphSAGE scoring of an uploaded transactions file |

The project ships a `Dockerfile` (which trains on the sample during build and
serves the API), a GitHub Actions CI workflow (installs dependencies, runs the
test suite, and smoke-trains on every push), and a dev-container for GitHub
Codespaces — so the repository is runnable both locally and in the cloud with no
manual setup.

---

## 10. Limitations

1. **Detection, not proof.** The system flags and ranks suspicious accounts; it
   does not prove laundering or auto-file a Suspicious Transaction Report. It is
   a prioritisation layer feeding human investigators and the existing EDD/STR
   process.
2. **Label definition.** An account is labelled mule if it touches any
   laundering transaction; finer-grained labelling (role within a typology)
   would allow richer multi-class modelling.
3. **Synthetic evaluation.** Reported figures are on synthetic data; real-world
   performance must be measured on the actual dataset and, ultimately, on
   de-identified bank data.
4. **Entity resolution.** Real bank data needs one-customer-to-one-node
   resolution before the graph is built; this is out of scope here.

---

## 11. Conclusion and Future Work

This project demonstrates a complete, reproducible money-mule detection system
built on a genuine Graph Neural Network (GraphSAGE) over a real transaction
graph (IBM AML). It shows that modelling the *network* of money movement — rather
than scoring accounts in isolation — is an effective and well-motivated approach
to mule detection, achieving strong ranking performance and producing an
investigator-ready risk report and API.

**Future work.**
- Run and report results on the full IBM HI-Small / HI-Large files.
- Add **explainability** (e.g. SHAP on node features, or GNN explainers) so each
  flagged account shows *why* it scored high.
- Model laundering **roles** (collector, forwarder, cash-out) as a multi-class
  problem.
- Add temporal / dynamic-graph modelling to catch evolving rings.
- Adapt the loader to de-identified bank warehouse (EDW) transactions mapped to
  the same `source, destination, amount, timestamp` schema, with entity
  resolution, for a bank pilot.

---

## References

1. W. L. Hamilton, R. Ying, J. Leskovec. *Inductive Representation Learning on
   Large Graphs* (GraphSAGE). NeurIPS, 2017.
2. E. Altman et al. *Realistic Synthetic Financial Transactions for
   Anti-Money Laundering Models*. 2023. (IBM Transactions for AML dataset.)
3. M. Weber et al. *Anti-Money Laundering in Bitcoin: Experimenting with Graph
   Convolutional Networks for Financial Forensics* (Elliptic dataset). 2019.
4. M. Fey, J. E. Lenssen. *Fast Graph Representation Learning with PyTorch
   Geometric*. 2019.
5. Financial Action Task Force (FATF) guidance on money mules and
   trade-based money laundering.

---

## Appendix A — How to run

```bash
# 1. install
pip install -r requirements.txt

# 2a. verify on the included synthetic sample (no download)
python src/make_sample.py
python src/train_graphsage.py --input data/sample_HI-Small_Trans.csv --epochs 30

# 2b. OR run on the real IBM data (download HI-Small_Trans.csv from Kaggle)
python src/train_graphsage.py --input /path/to/HI-Small_Trans.csv --epochs 30

# 3. serve the investigator API
uvicorn src.serve:app --port 8000     # open http://localhost:8000/docs
```

Outputs appear in `outputs/` (`metrics.json`, `account_risk_report.csv`) and
`models/graphsage_aml.pt`.
