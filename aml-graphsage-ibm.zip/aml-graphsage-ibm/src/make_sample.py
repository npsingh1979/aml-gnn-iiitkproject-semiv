"""
make_sample.py — Generate a SCHEMA-EXACT IBM-AML sample file for local testing.

The output CSV has the identical columns and value styles as the real Kaggle
file (HI-Small_Trans.csv), so `ibm_aml.load_transactions()` reads it through the
very same code path as the real data. It embeds real laundering typologies
(fan-in collector, fan-out distributor, pass-through chains, cycles) flagged
with Is Laundering = 1, on a background of normal peer-to-peer payments.

This is NOT a substitute for the real dataset — it exists only so the GraphSAGE
pipeline can be verified end-to-end before you drop in the downloaded file.
"""
from __future__ import annotations

import argparse
import random
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

CURRENCIES = ["US Dollar", "Euro", "Rupee", "UK Pound"]
FORMATS = ["ACH", "Cheque", "Credit Card", "Wire", "Reinvestment"]
CASHOUT = ["Cash", "Bitcoin"]
T0 = datetime(2022, 9, 1, 0, 0)


def _ts(minutes):
    return (T0 + timedelta(minutes=int(minutes))).strftime("%Y/%m/%d %H:%M")


def _acct(bank, rng):
    return bank, f"{rng.randint(0, 0xFFFFFF):06X}{rng.randint(0,9)}"


def generate(n_accounts=4000, n_banks=12, laundering_rings=60, seed=42):
    rng = random.Random(seed)
    np.random.seed(seed)
    rows = []

    accts = [_acct(rng.randint(10, 10 + n_banks), rng) for _ in range(n_accounts)]

    # ---- background legitimate traffic -----------------------------------
    for _ in range(n_accounts * 4):
        a = rng.choice(accts); b = rng.choice(accts)
        if a == b:
            continue
        amt = round(rng.uniform(50, 9000), 2)
        cur = rng.choice(CURRENCIES)
        rows.append([_ts(rng.randint(0, 60 * 24 * 30)), a[0], a[1], b[0], b[1],
                     amt, cur, amt, cur, rng.choice(FORMATS), 0])

    # ---- laundering typologies -------------------------------------------
    for r in range(laundering_rings):
        typ = r % 4
        base_t = rng.randint(0, 60 * 24 * 28)
        cur = rng.choice(CURRENCIES)

        if typ == 0:  # FAN-IN: many sources -> one collector mule
            collector = rng.choice(accts)
            amt = round(rng.uniform(4000, 9500), 2)
            for k in range(rng.randint(6, 12)):
                src = rng.choice(accts)
                rows.append([_ts(base_t + k * 7), src[0], src[1], collector[0], collector[1],
                             amt, cur, amt, cur, "Wire", 1])
            # collector cashes out
            sink = rng.choice(accts)
            rows.append([_ts(base_t + 120), collector[0], collector[1], sink[0], sink[1],
                         amt * 6, cur, amt * 6, cur, rng.choice(CASHOUT), 1])

        elif typ == 1:  # FAN-OUT: one source -> many mules
            distributor = rng.choice(accts)
            amt = round(rng.uniform(3000, 8000), 2)
            for k in range(rng.randint(6, 12)):
                dst = rng.choice(accts)
                rows.append([_ts(base_t + k * 5), distributor[0], distributor[1], dst[0], dst[1],
                             amt, cur, amt, cur, "ACH", 1])

        elif typ == 2:  # PASS-THROUGH CHAIN: A->B->C->D rapid, near-equal amounts
            chain = [rng.choice(accts) for _ in range(rng.randint(4, 6))]
            amt = round(rng.uniform(5000, 9000), 2)
            for k in range(len(chain) - 1):
                a, b = chain[k], chain[k + 1]
                rows.append([_ts(base_t + k * 3), a[0], a[1], b[0], b[1],
                             round(amt * (0.97 ** k), 2), cur, round(amt * (0.97 ** k), 2), cur,
                             "Wire", 1])

        else:  # CYCLE: A->B->C->A
            cyc = [rng.choice(accts) for _ in range(3)]
            amt = round(rng.uniform(4000, 9000), 2)
            for k in range(3):
                a, b = cyc[k], cyc[(k + 1) % 3]
                rows.append([_ts(base_t + k * 4), a[0], a[1], b[0], b[1],
                             amt, cur, amt, cur, "Wire", 1])

    cols = ["Timestamp", "From Bank", "Account", "To Bank", "Account.1",
            "Amount Received", "Receiving Currency", "Amount Paid",
            "Payment Currency", "Payment Format", "Is Laundering"]
    df = pd.DataFrame(rows, columns=cols)
    df = df.sample(frac=1.0, random_state=seed).reset_index(drop=True)  # shuffle
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/sample_HI-Small_Trans.csv")
    ap.add_argument("--accounts", type=int, default=4000)
    ap.add_argument("--rings", type=int, default=60)
    args = ap.parse_args()
    df = generate(n_accounts=args.accounts, laundering_rings=args.rings)
    df.to_csv(args.out, index=False)
    print(f"wrote {args.out}  rows={len(df):,}  laundering_txns={int(df['Is Laundering'].sum()):,}")
