"""AML GraphSAGE on the IBM Transactions-for-AML dataset."""
__version__ = "1.0.0"
