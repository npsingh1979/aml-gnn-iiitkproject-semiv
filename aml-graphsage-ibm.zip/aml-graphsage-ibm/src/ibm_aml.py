"""
ibm_aml.py — Load the IBM "Transactions for Anti-Money Laundering (AML)" dataset
and turn it into an account-level transaction graph for GraphSAGE.

Dataset: https://www.kaggle.com/datasets/ealtman2019/ibm-transactions-for-anti-money-laundering-aml
Files look like HI-Small_Trans.csv / LI-Large_Trans.csv with columns:

    Timestamp, From Bank, Account, To Bank, Account.1,
    Amount Received, Receiving Currency, Amount Paid, Payment Currency,
    Payment Format, Is Laundering

Each ROW is one transaction (a directed edge: Account -> Account.1).
We build:
  * nodes  = unique accounts, keyed as "<Bank>_<Account>"
  * edges  = transactions (directed, with amount / timestamp / payment format)
  * label  = 1 if the account takes part in ANY laundering transaction, else 0
             (standard node-level label for IBM-AML node classification)
  * feats  = per-account behavioural features derived purely from the edges

This same module is used for the real Kaggle file AND for the schema-exact
sample generator, so the code path is identical in both cases.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

# Canonical column names in the raw IBM AML file
RAW_COLS = [
    "Timestamp", "From Bank", "Account", "To Bank", "Account.1",
    "Amount Received", "Receiving Currency", "Amount Paid",
    "Payment Currency", "Payment Format", "Is Laundering",
]


def load_transactions(path: str, nrows: int | None = None) -> pd.DataFrame:
    """Read a raw IBM AML *_Trans.csv and normalise it to a canonical edge table.

    Returns a DataFrame with columns:
        src, dst, amount, timestamp, pay_format, currency, is_laundering
    where src/dst are string node ids "<Bank>_<Account>".
    """
    df = pd.read_csv(path, nrows=nrows)

    # Be tolerant of minor header variants (some mirrors rename the 2nd account)
    cols = list(df.columns)
    if "Account.1" not in cols and len(cols) >= 5 and cols[2] == "Account":
        # pandas appends .1 to the duplicate 'Account' header; if a mirror used
        # a different spelling, map the 5th column positionally.
        df = df.rename(columns={cols[4]: "Account.1"})

    missing = [c for c in RAW_COLS if c not in df.columns]
    if missing:
        raise ValueError(
            f"Input does not look like IBM AML data. Missing columns: {missing}\n"
            f"Found: {list(df.columns)}"
        )

    src = df["From Bank"].astype(str) + "_" + df["Account"].astype(str)
    dst = df["To Bank"].astype(str) + "_" + df["Account.1"].astype(str)

    out = pd.DataFrame({
        "src": src.values,
        "dst": dst.values,
        "amount": pd.to_numeric(df["Amount Paid"], errors="coerce").fillna(0.0).values,
        "timestamp": pd.to_datetime(df["Timestamp"], errors="coerce").values,
        "pay_format": df["Payment Format"].astype(str).values,
        "currency": df["Payment Currency"].astype(str).values,
        "is_laundering": pd.to_numeric(df["Is Laundering"], errors="coerce").fillna(0).astype(int).values,
    })
    # Drop self-loops (an account paying itself is not a graph edge of interest)
    out = out[out["src"] != out["dst"]].reset_index(drop=True)
    return out


def build_account_graph(edges: pd.DataFrame):
    """From the canonical edge table build node ids, labels, features and edge_index.

    Returns dict with:
        node_ids   : list[str]              (index position == node index)
        features   : np.ndarray [N, F]
        feat_names : list[str]
        labels     : np.ndarray [N]         (0/1 account-level)
        edge_index : np.ndarray [2, E]      (directed src->dst, int node indices)
        edge_amount: np.ndarray [E]
    """
    # ---- node index -------------------------------------------------------
    nodes = pd.Index(pd.unique(pd.concat([edges["src"], edges["dst"]], ignore_index=True)))
    node_pos = {n: i for i, n in enumerate(nodes)}
    s = edges["src"].map(node_pos).to_numpy()
    d = edges["dst"].map(node_pos).to_numpy()
    N = len(nodes)

    amt = edges["amount"].to_numpy(dtype=float)
    ts = pd.to_datetime(edges["timestamp"])
    laundering = edges["is_laundering"].to_numpy(dtype=int)

    # ---- account-level label: involved in any laundering txn --------------
    labels = np.zeros(N, dtype=int)
    lw = laundering == 1
    np.maximum.at(labels, s[lw], 1)
    np.maximum.at(labels, d[lw], 1)

    # ---- outgoing / incoming aggregates -----------------------------------
    def agg(by, prefix):
        g = pd.DataFrame({"node": by, "amount": amt, "cp": (d if prefix == "out" else s),
                          "ts": ts.values})
        out = pd.DataFrame(index=range(N))
        gb = g.groupby("node")
        out[f"{prefix}_deg"] = gb.size().reindex(range(N)).fillna(0).values
        out[f"{prefix}_amt_sum"] = gb["amount"].sum().reindex(range(N)).fillna(0).values
        out[f"{prefix}_amt_mean"] = gb["amount"].mean().reindex(range(N)).fillna(0).values
        out[f"{prefix}_amt_max"] = gb["amount"].max().reindex(range(N)).fillna(0).values
        out[f"{prefix}_uniq_cp"] = gb["cp"].nunique().reindex(range(N)).fillna(0).values
        return out

    out_f = agg(s, "out")   # node as sender
    in_f = agg(d, "in")     # node as receiver

    feats = pd.concat([out_f, in_f], axis=1)

    # ---- derived mule-signal features -------------------------------------
    sent = feats["out_amt_sum"]
    recv = feats["in_amt_sum"]
    denom = np.maximum(sent + recv, 1.0)
    feats["net_flow_ratio"] = (recv - sent) / denom           # ~0 => pass-through
    feats["passthrough_ratio"] = np.minimum(sent, recv) / np.maximum(np.maximum(sent, recv), 1.0)
    feats["total_degree"] = feats["out_deg"] + feats["in_deg"]
    feats["fan_in_ratio"] = feats["in_uniq_cp"] / np.maximum(feats["in_deg"], 1.0)
    feats["fan_out_ratio"] = feats["out_uniq_cp"] / np.maximum(feats["out_deg"], 1.0)
    feats["recv_to_sent_amt"] = recv / np.maximum(sent, 1.0)

    # ---- cash-out / payment-format mix per sender -------------------------
    fmt = pd.DataFrame({"node": s, "pay_format": edges["pay_format"].values})
    cash_like = fmt["pay_format"].str.contains("Cash|Bitcoin", case=False, na=False).astype(int)
    fmt["cash_like"] = cash_like.values
    cash_ratio = fmt.groupby("node")["cash_like"].mean().reindex(range(N)).fillna(0.0)
    feats["cash_out_ratio"] = cash_ratio.values

    # ---- temporal burst (txns within the account's busiest day) -----------
    tdf = pd.DataFrame({"node": np.concatenate([s, d]),
                        "ts": np.concatenate([ts.values, ts.values])})
    tdf = tdf.dropna(subset=["ts"])
    if len(tdf):
        tdf["day"] = pd.to_datetime(tdf["ts"]).dt.floor("D")
        per_day = tdf.groupby(["node", "day"]).size()
        burst = per_day.groupby(level=0).max().reindex(range(N)).fillna(0)
        active_days = tdf.groupby("node")["day"].nunique().reindex(range(N)).fillna(0)
    else:
        burst = pd.Series(0, index=range(N))
        active_days = pd.Series(0, index=range(N))
    feats["max_txns_per_day"] = burst.values
    feats["active_days"] = active_days.values

    feats = feats.fillna(0.0)
    feat_names = list(feats.columns)
    features = feats.to_numpy(dtype=np.float32)

    edge_index = np.vstack([s, d]).astype(np.int64)

    return {
        "node_ids": list(nodes),
        "features": features,
        "feat_names": feat_names,
        "labels": labels.astype(np.int64),
        "edge_index": edge_index,
        "edge_amount": amt.astype(np.float32),
    }
