import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)                      # so `import src.serve` works
sys.path.insert(0, os.path.join(ROOT, "src"))  # so `import ibm_aml` works
