# AML GraphSAGE — IBM Transactions for Anti-Money Laundering

![CI](https://github.com/OWNER/aml-graphsage-ibm/actions/workflows/ci.yml/badge.svg)
![Python](https://img.shields.io/badge/python-3.11-blue)
![License](https://img.shields.io/badge/license-MIT-green)

A **real graph-neural-network** (GraphSAGE, PyTorch Geometric) money-mule / AML
detector that trains on the **IBM "Transactions for Anti-Money Laundering (AML)"**
dataset — an actual account-to-account money-flow graph, not tabular features —
and serves per-account risk scores over a FastAPI investigator API.

- **Dataset:** <https://www.kaggle.com/datasets/ealtman2019/ibm-transactions-for-anti-money-laundering-aml>
- **Model:** 2-layer GraphSAGE node classification, class-weighted for the rare
  mule class, full-batch on CPU.
- **Why a GNN fits here:** every row is a transaction `Account → Account.1` with
  amount, timestamp and a laundering flag, so a genuine transaction graph exists
  and message passing propagates mule signal along the money flows. (Tabular
  datasets with no counterparty links — credit-card, IEEE-CIS — cannot support a
  GNN; this one can.)

> **No dataset files are committed.** The only data in the repo
> (`data/sample_HI-Small_Trans.csv`) is **synthetic**, produced by
> `src/make_sample.py` in the exact IBM schema, so everything runs out of the box
> and the real file drops straight in.

---

## Quick start

```bash
pip install -r requirements.txt          # or: make install
python src/make_sample.py                 # schema-exact sample -> data/
python src/train_graphsage.py --input data/sample_HI-Small_Trans.csv --epochs 30
uvicorn src.serve:app --port 8000         # investigator API at /docs
```

On the sample this reaches **ROC-AUC ≈ 0.90 at recall 0.80**. On the real
HI-Small graph the structured typologies and much larger neighbourhoods give
materially stronger separation.

## Run on the REAL dataset (one command)

1. Download `HI-Small_Trans.csv` from the Kaggle page above (free account).
2. Train:

```bash
python src/train_graphsage.py --input /path/to/HI-Small_Trans.csv --epochs 30
```

The suite also ships HI-Medium / HI-Large / LI-*; for the big ones cap rows while
iterating (`--nrows 2000000`) or switch to `NeighborLoader` mini-batching
(`pip install torch-sparse pyg-lib`; one-line change noted in
`src/train_graphsage.py`).

### Run on Kaggle (zero download — data already mounted)

New Notebook on the dataset page → *Add Data* → then:

```python
!pip -q install torch_geometric
!python train_graphsage.py --input /kaggle/input/ibm-transactions-for-anti-money-laundering-aml/HI-Small_Trans.csv --epochs 30
```

## What the model learns

Accounts (`<Bank>_<Account>`) are nodes; transactions are directed edges. An
account is labelled laundering (1) if it takes part in any `Is Laundering = 1`
transaction. Features are derived **purely from the graph**:

| group | features |
|---|---|
| degree | `out_deg`, `in_deg`, `total_degree` |
| counterparties | `out_uniq_cp`, `in_uniq_cp`, `fan_in_ratio`, `fan_out_ratio` |
| amounts | sum / mean / max sent & received, `recv_to_sent_amt` |
| mule signal | `net_flow_ratio`, `passthrough_ratio` (≈ money in = money out) |
| cash-out | `cash_out_ratio` (Cash / Bitcoin exit) |
| temporal | `max_txns_per_day`, `active_days` |

GraphSAGE aggregates each account's neighbourhood over two hops to classify it.

## Outputs

| file | contents |
|---|---|
| `outputs/metrics.json` | PR-AUC, ROC-AUC, precision/recall/F1, confusion matrix (val + test) |
| `outputs/account_risk_report.csv` | every account ranked by GraphSAGE risk score |
| `models/graphsage_aml.pt` | trained weights |

## API

```bash
make serve      # http://localhost:8000/docs
```

| method | path | purpose |
|---|---|---|
| GET | `/health` | service + model/report status |
| GET | `/stats` | graph size, flagged count, labelled mules |
| GET | `/accounts/top?n=20` | highest-risk accounts |
| GET | `/accounts/{id}` | risk for one account |
| POST | `/score` | live GraphSAGE scoring of a transactions file |

## Docker

```bash
make docker-build && make docker-run     # trains on the sample during build, serves on :8000
```

## Tests & CI

```bash
make install-dev && make test
```

GitHub Actions (`.github/workflows/ci.yml`) installs the CPU PyTorch wheel, runs
the test suite, smoke-trains on the sample, and uploads the metrics/risk report
as build artifacts on every push.

## Project layout

```
src/ibm_aml.py          loader + account-graph / feature builder (real + sample)
src/make_sample.py      schema-exact IBM-AML sample generator (mule typologies)
src/train_graphsage.py  GraphSAGE training, evaluation, risk report
src/serve.py            FastAPI investigator API
tests/                  loader, end-to-end training, and API tests
.github/workflows/ci.yml
Dockerfile · Makefile · requirements*.txt
docs/ARCHITECTURE.md
docs/PROJECT_REPORT.md   full project report (also docs/PROJECT_REPORT.docx)
```

## Project report

A full write-up — abstract, problem statement, methodology, results and
limitations — is in [`docs/PROJECT_REPORT.md`](docs/PROJECT_REPORT.md), with a
formatted Word version at `docs/PROJECT_REPORT.docx`.

## Adapting to bank data

The same pipeline accepts de-identified warehouse transactions mapped to the
canonical `src, dst, amount, timestamp, pay_format, is_laundering` schema in
`ibm_aml.load_transactions`. Swap the loader's column mapping and the rest is
unchanged.

## License

MIT (code). The IBM AML dataset is governed by IBM's own terms on Kaggle and is
not distributed here. See `LICENSE`.
